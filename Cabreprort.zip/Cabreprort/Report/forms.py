from django import forms

class NameForm(forms.Form):

    office_location = forms.ChoiceField(choices=[('durgapur','Durgapur'),('kolkata','Kolkata'), ('pune','Pune')], label='Office Location')
    start_date = forms.DateField(label='Start Date')
    end_date = forms.DateField(label='End Date')
    service_type = forms.ChoiceField(choices=[('all', 'All'), ('free', 'Free'), ('paid', 'Paid'), ('paid share', 'Paid Share')],
                                        label='Service Type')
    driver = forms.ChoiceField(choices=[('choose driver', 'Choose Driver'), ('uday auto', 'Uday Auto'), ('raju auto', 'Raju Auto')],
                                        label='Driver')