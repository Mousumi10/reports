from django.contrib import admin
from .models import CabProcessing


admin.site.register(CabProcessing)
